export default function AdvisorChat() {
  return (
    <div className="card flex h-full flex-col p-6">
      <h2 className="mb-5 text-2xl font-bold">
        Advisor Chat
      </h2>

      <div className="mb-4 flex-1 space-y-4">
        <div className="rounded-xl bg-slate-900 p-4 text-sm">
          Can I graduate in 3 semesters?
        </div>

        <div className="rounded-xl bg-blue-500/20 p-4 text-sm text-blue-100">
          Based on your current workload settings,
          you may need one heavier semester.
        </div>
      </div>

      <textarea
        rows={4}
        placeholder="Ask your advisor..."
        className="w-full rounded-xl border border-slate-700 bg-slate-900 p-3"
      />

      <button className="mt-3 w-full rounded-xl bg-blue-600 px-4 py-3 font-semibold hover:bg-blue-500">
        Send
      </button>
    </div>
  );
}
