type Props = {
  profile: {
    name: string;
    degree: string;
    targetGraduation: string;
  };
};

export default function StudentProfilePanel({ profile }: Props) {
  return (
    <div className="card p-6">
      <h2 className="mb-5 text-2xl font-bold">
        Student Profile
      </h2>

      <div className="space-y-4">
        <div>
          <p className="text-sm text-slate-400">Name</p>
          <p>{profile.name}</p>
        </div>

        <div>
          <p className="text-sm text-slate-400">Degree</p>
          <p>{profile.degree}</p>
        </div>

        <div>
          <p className="text-sm text-slate-400">
            Target Graduation
          </p>
          <p>{profile.targetGraduation}</p>
        </div>
      </div>

      <button className="mt-6 w-full rounded-xl bg-blue-600 px-4 py-3 font-semibold hover:bg-blue-500">
        Regenerate Plan
      </button>
    </div>
  );
}
