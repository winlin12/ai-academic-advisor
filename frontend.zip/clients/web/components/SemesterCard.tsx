import CoursePill from "./CoursePill";

type Course = {
  code: string;
  name: string;
};

type Props = {
  title: string;
  credits: number;
  warning: string;
  courses: Course[];
};

export default function SemesterCard({
  title,
  credits,
  warning,
  courses,
}: Props) {
  return (
    <div className="card p-6">
      <div className="mb-4 flex items-center justify-between">
        <div>
          <h2 className="text-2xl font-bold">{title}</h2>
          <p className="text-sm text-slate-400">
            {credits} credits
          </p>
        </div>

        <div className="rounded-full bg-yellow-500/20 px-3 py-1 text-xs text-yellow-300">
          {warning}
        </div>
      </div>

      <div className="space-y-3">
        {courses.map((course) => (
          <CoursePill
            key={course.code}
            code={course.code}
            name={course.name}
          />
        ))}
      </div>
    </div>
  );
}
