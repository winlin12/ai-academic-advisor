type Props = {
  code: string;
  name: string;
};

export default function CoursePill({ code, name }: Props) {
  return (
    <div className="rounded-xl border border-slate-700 bg-slate-900 p-4">
      <p className="font-semibold">{code}</p>
      <p className="text-sm text-slate-400">{name}</p>
    </div>
  );
}
