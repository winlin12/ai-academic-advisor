import SemesterCard from "@/components/SemesterCard";
import StudentProfilePanel from "@/components/StudentProfilePanel";
import AdvisorChat from "@/components/AdvisorChat";
import { mockProfile, semesters } from "@/lib/mockData";

export default function HomePage() {
  return (
    <main className="min-h-screen bg-slate-950 p-8">
      <div className="mb-8">
        <h1 className="text-5xl font-bold">
          AI Academic Advisor
        </h1>

        <p className="mt-2 text-slate-400">
          AI-powered semester planning dashboard
        </p>
      </div>

      <div className="grid grid-cols-12 gap-6">
        <div className="col-span-3">
          <StudentProfilePanel profile={mockProfile} />
        </div>

        <div className="col-span-6 space-y-6">
          {semesters.map((semester) => (
            <SemesterCard
              key={semester.title}
              title={semester.title}
              credits={semester.credits}
              warning={semester.warning}
              courses={semester.courses}
            />
          ))}
        </div>

        <div className="col-span-3">
          <AdvisorChat />
        </div>
      </div>
    </main>
  );
}
